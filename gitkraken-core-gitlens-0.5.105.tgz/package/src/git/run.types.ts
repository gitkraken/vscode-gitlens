import type { CacheController } from '../utils/promiseCache.js';
import type { GitWarningKey } from './errors.js';

export type GitErrorHandling = 'throw' | 'ignore';

/**
 * Why a run was aborted. DIAGNOSTIC ONLY — log it, never branch control flow on it. A timeout kill and a
 * caller abort both terminate the process with SIGTERM and surface as the same error, so this is derived
 * from a duration heuristic and can be wrong near the timeout boundary.
 */
export type GitRunCancellation = 'aborted' | 'timeout' | 'unknown';

/**
 * Why a run produced no answer. Every value is structurally distinguishable, so these are safe to branch on.
 *
 * There is deliberately no `untrusted` member: an untrusted workspace is refused before the command is ever
 * attempted, so it REJECTS with `WorkspaceUntrustedError` rather than resolving a result.
 */
export type GitRunFailure =
	/** Terminated by a signal other than SIGTERM. Any `stdout` is partial. */
	| 'signal'
	/** No process ever ran — queue rejection, spawn failure (e.g. ENOENT). */
	| 'unstarted';

/**
 * How a run ended — the answer to "can I trust `stdout`?", which `exitCode` alone cannot give.
 *
 * A non-zero exit is NOT a failure: `diff --quiet` exits 1 for "differences found", `merge-base
 * --is-ancestor` for "no". Those are answers, and they're `exited`. What callers must not do is read the
 * empty `stdout` of a `warned`/`cancelled`/`failed` run as a real result — which is what a bare
 * `exitCode === 0` check does, since several failure paths report zero.
 */
export type GitRunCompletion =
	/** Ran to completion. Interpreting `code` is the caller's business; `stdout` is trustworthy. */
	| { readonly status: 'exited'; readonly code: number }
	/**
	 * Exited non-zero, but stderr matched a known-benign pattern, so the error was swallowed and `stdout`
	 * is empty. Whether that empty is a real ANSWER (`noCommits` on a fresh repo) or a failure
	 * (`notARepository`) depends on `warning` — it is never safe to read as a plain empty result.
	 *
	 * `warning` is `undefined` for a swallow that matched no table entry; treat that like any warning you
	 * haven't explicitly whitelisted, i.e. not an answer. The process did exit, so `exitCode` is present
	 * whenever git reported a numeric one.
	 */
	| { readonly status: 'warned'; readonly warning: GitWarningKey | undefined; readonly error: Error }
	| { readonly status: 'cancelled'; readonly reason: GitRunCancellation; readonly error: Error }
	| { readonly status: 'failed'; readonly reason: GitRunFailure; readonly error: Error };

export type GitResult<T extends string | Buffer | unknown = string> = {
	/**
	 * The process's exit code. ABSENT when no process exited — see {@link completion}. Deliberately optional:
	 * defaulting to `0` made a failed run indistinguishable from a clean success.
	 */
	readonly exitCode?: number;
	readonly stdout: T;
	readonly stderr?: T;

	readonly completion: GitRunCompletion;
};

/**
 * Cache store interface for git command output caching.
 * Stores full GitResult to preserve exitCode/stderr.
 */
export interface GitResultCache {
	getOrCreate(
		repoPath: string,
		key: string,
		// `signal` is the aggregate cancellation — it fires only when every current caller has aborted.
		// Bind shared work to it (not any single caller's signal) so one caller's abort can't reject riders.
		factory: (cacheable: CacheController, signal?: AbortSignal) => Promise<GitResult<unknown>>,
		options?: { createTTL?: number; accessTTL?: number; cancellation?: AbortSignal },
	): Promise<GitResult<unknown>>;
}

/**
 * Priority levels for git commands.
 * - `interactive`: User-initiated operations (blame, hover) - highest priority
 * - `normal`: Standard operations (status, config) - default priority
 * - `background`: Expensive operations (graph rendering, full history walks) - can be throttled
 */
export type GitCommandPriority = 'interactive' | 'normal' | 'background';

export interface GitRunOptions {
	cancellation?: AbortSignal;
	configs?: readonly string[];
	readonly correlationKey?: string;
	errors?: GitErrorHandling;
	/** Priority level for queue ordering. If not specified, will be inferred from the command type. */
	priority?: GitCommandPriority;
	/** Specifies that this command should always be executed locally if possible (for live share sessions) */
	runLocally?: boolean;

	/**
	 * If provided, cache the command's result (stdout, stderr, exitCode) in this store via an auto-generated cache key
	 * Only use for commands with stable output (e.g., `git remote -v`)
	 */
	caching?: {
		cache: GitResultCache;
		/** The common repository path for worktree-shared caching. If not provided, defaults to cwd. */
		commonPath?: string;
		options?: { createTTL?: number; accessTTL?: number };
	};

	// Below options comes from RunOptions<BufferEncoding | 'buffer' | string>
	cwd?: string;
	readonly env?: Record<string, string | undefined>;
	readonly encoding?: BufferEncoding | 'buffer' | string;
	readonly maxBuffer?: number;
	readonly stdin?: string | Buffer;
	readonly stdinEncoding?: string;
	// Set to 0 to disable
	readonly timeout?: number;
}

/**
 * Untyped escape hatch for raw `git <args>` invocation, returned by
 * `GlGitProvider.createUnsafeGit`.
 *
 * "Unsafe" here means **bypasses the typed safety net** the rest of GitLens relies on
 * — sub-provider cancellation/caching/decorator behaviors and signing-awareness do
 * not apply when commands are issued through this object. It does NOT imply command
 * injection risk; the caller still controls the args.
 *
 * Hand instances to libraries that need to issue arbitrary git commands
 * (`@gitkraken/compose-tools`, `@gitkraken/shared-tools` undo). Inside GitLens
 * itself, prefer the typed sub-providers on `RepositoryService` (`branches`,
 * `commits`, `diff`, `staging`, `stash`, `status`, …). Holding an `UnsafeGit`
 * just to call `run(...)` for an ad-hoc command is almost always wrong — the
 * abstraction exists so it can be handed off, not used directly.
 */
export interface UnsafeGit {
	run(args: readonly string[], options?: GitRunOptions): Promise<GitResult>;
}

export interface GitSpawnOptions {
	cancellation?: AbortSignal;
	configs?: readonly string[];

	// Below options comes from SpawnOptions
	cwd?: string;
	readonly env?: Record<string, string | undefined>;
	readonly encoding?: BufferEncoding | 'buffer' | string;
	readonly stdin?: string | Buffer;
	readonly stdinEncoding?: string;
	// Set to 0 to disable
	readonly timeout?: number;
}
