import type { Cache } from '../../git/cache.js';
import type { GitServiceContext } from '../../git/context.js';
import { TagError } from '../../git/errors.js';
import { GitTag } from '../../git/models/tag.js';
import type { GitTagsSubProvider } from '../../git/providers/tags.js';
import type { TagSortOptions } from '../../git/utils/sorting.js';
import { sortTags } from '../../git/utils/sorting.js';
import { filterMap } from '../../utils/array.js';
import { isCancellationError } from '../../utils/cancellation.js';
import { debug } from '../../utils/decorators/log.js';
import { getScopedLogger } from '../../utils/logger.scoped.js';
import type { PagedResult, PagingOptions } from '../../utils/paging.js';
import { emptyPagedResult } from '../../utils/paging.js';
import { maybeStopWatch } from '../../utils/stopwatch.js';
import type { CliGitProviderInternal } from '../cliGitProvider.js';
import type { GitResult } from '../exec/exec.types.js';
import type { Git, GitError } from '../exec/git.js';
import { getGitCommandError, gitConfigsBranch } from '../exec/git.js';

export class TagsGitSubProvider implements GitTagsSubProvider {
	constructor(
		private readonly context: GitServiceContext,
		private readonly git: Git,
		private readonly cache: Cache,
		private readonly provider: CliGitProviderInternal,
	) {}

	@debug()
	async getTag(repoPath: string, name: string, cancellation?: AbortSignal): Promise<GitTag | undefined> {
		const {
			values: [tag],
		} = await this.getTags(repoPath, { filter: t => t.name === name }, cancellation);
		return tag;
	}

	@debug({ args: repoPath => ({ repoPath: repoPath }) })
	async getTags(
		repoPath: string,
		options?: {
			filter?: (t: GitTag) => boolean;
			paging?: PagingOptions;
			sort?: boolean | TagSortOptions;
		},
		cancellation?: AbortSignal,
	): Promise<PagedResult<GitTag>> {
		if (!repoPath) return emptyPagedResult;

		const scope = getScopedLogger();

		let tagsResult = await this.cache.getTags(
			repoPath,
			async (commonPath, _cacheable, signal) => {
				// Prefer the aggregate signal from the cache; fall back to the caller's cancellation.
				signal ??= cancellation;
				try {
					const records = await this.provider.refs.getRefs(commonPath, signal);
					if (!records.length) return emptyPagedResult;

					using sw = maybeStopWatch(scope, { log: { onlyExit: true, level: 'debug' } });

					const tags: GitTag[] = [];

					for (const record of records) {
						const fullName = record.name;
						if (!fullName.startsWith('refs/tags/')) continue;

						// Annotated tags: peeledObjectname is the commit SHA; objectname is the tag-object SHA.
						// Lightweight tags: peeledObjectname is empty; objectname is already the commit SHA.
						const annotated = Boolean(record.peeledObjectname);
						const sha = record.peeledObjectname || record.objectname;

						tags.push(
							new GitTag(
								commonPath,
								fullName,
								sha,
								record.subject,
								record.creatorDate ? new Date(record.creatorDate) : undefined,
								record.authorDate ? new Date(record.authorDate) : undefined,
								annotated,
							),
						);
					}

					sw?.stop({ suffix: ` parsed ${String(tags.length)} tags` });

					return { values: tags };
				} catch (ex) {
					scope?.error(ex);
					if (isCancellationError(ex)) throw ex;

					return emptyPagedResult;
				}
			},
			cancellation,
		);

		if (options?.filter != null) {
			tagsResult = {
				...tagsResult,
				values: tagsResult.values.filter(options.filter),
			};
		}

		if (options?.sort) {
			sortTags(tagsResult.values, typeof options.sort === 'boolean' ? undefined : options.sort);
		}

		return tagsResult;
	}

	@debug()
	async getTagsWithCommit(
		repoPath: string,
		sha: string,
		options?: { commitDate?: Date; mode?: 'contains' | 'pointsAt' },
		cancellation?: AbortSignal,
	): Promise<string[]> {
		const result = await this.tagsContainingCore(repoPath, sha, options, cancellation);
		if (!result.stdout) return [];

		return filterMap(result.stdout.split('\n'), b => b.trim() || undefined);
	}

	private async tagsContainingCore(
		repoPath: string,
		sha: string,
		options?: { mode?: 'contains' | 'pointsAt' },
		cancellation?: AbortSignal,
	): Promise<GitResult> {
		const params: string[] = ['tag', '--format=%(refname:short)'];
		params.push(options?.mode === 'pointsAt' ? `--points-at=${sha}` : `--contains=${sha}`);

		return this.git.run(
			{
				cwd: repoPath,
				cancellation: cancellation,
				configs: gitConfigsBranch,
				errors: 'ignore',
			},
			...params,
		);
	}

	@debug()
	async createTag(repoPath: string, name: string, sha: string, message?: string): Promise<void> {
		const args = ['tag', name, sha];
		if (message != null && message.length > 0) {
			args.push('-m', message);
		}

		try {
			await this.git.run({ cwd: repoPath }, ...args);
			this.context.hooks?.cache?.onReset?.(repoPath, 'tags');
			this.context.hooks?.repository?.onChanged?.(repoPath, ['tags']);
		} catch (ex) {
			throw getGitCommandError(
				'tag',
				ex as GitError,
				reason =>
					new TagError(
						{ reason: reason, action: 'create', tag: name, gitCommand: { repoPath: repoPath, args: args } },
						ex as GitError,
					),
			);
		}
	}

	@debug()
	async deleteTag(repoPath: string, name: string): Promise<void> {
		const args = ['tag', '-d', name];

		try {
			await this.git.run({ cwd: repoPath }, ...args);
			this.context.hooks?.cache?.onReset?.(repoPath, 'tags');
			this.context.hooks?.repository?.onChanged?.(repoPath, ['tags']);
		} catch (ex) {
			throw getGitCommandError(
				'tag',
				ex as GitError,
				reason =>
					new TagError(
						{ reason: reason, action: 'delete', tag: name, gitCommand: { repoPath: repoPath, args: args } },
						ex as GitError,
					),
			);
		}
	}
}
