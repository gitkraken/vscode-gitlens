import type { MergeConflictFile } from '../../git/models/mergeConflicts.js';
import { map } from '../../utils/iterable.js';
import { maybeStopWatch } from '../../utils/stopwatch.js';
import { iterateByDelimiter } from '../../utils/string.js';

export interface GitMergeConflict {
	treeOid: string;
	conflicts: MergeConflictFile[];
}

export function parseMergeTreeConflict(data: string): GitMergeConflict {
	using sw = maybeStopWatch(`Git.parseMergeTreeConflict`, { log: { onlyExit: true, level: 'debug' } });

	const lines = iterateByDelimiter(data, '\0');
	const treeOid = lines.next();

	const conflicts = treeOid.done ? [] : [...map(lines, l => ({ path: l }))];

	sw?.stop({ suffix: ` parsed ${conflicts.length} conflicts` });

	return { treeOid: treeOid.value, conflicts: conflicts };
}
