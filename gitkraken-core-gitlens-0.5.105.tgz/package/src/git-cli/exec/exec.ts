export {
	CancelledRunError,
	findExecutable,
	fsExists,
	getWindowsShortPath,
	run,
	RunError,
	runSpawn,
} from '../../utils/env/node/exec.js';
export type { RunExitResult, RunOptions, RunResult } from '../../utils/env/node/exec.js';
export { isWindows } from '../../utils/env/node/platform.js';
