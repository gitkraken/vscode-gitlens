import type { Account, UnidentifiedAuthor } from '../../../git/models/author.js';
import type { DefaultBranch } from '../../../git/models/defaultBranch.js';
import type { Issue, IssueShape } from '../../../git/models/issue.js';
import type { IssueOrPullRequest, IssueOrPullRequestType } from '../../../git/models/issueOrPullRequest.js';
import type {
	PullRequest,
	PullRequestMergeMethod,
	PullRequestState,
	PullRequestStateFilter,
} from '../../../git/models/pullRequest.js';
import type { GitRemote } from '../../../git/models/remote.js';
import type { RepositoryMetadata } from '../../../git/models/repositoryMetadata.js';
import { CancellationError } from '../../../utils/cancellation.js';
import { md5 } from '../../../utils/crypto.js';
import type { Emitter } from '../../../utils/event.js';
import type { PagedResult } from '../../../utils/paging.js';
import { nonnullSettled } from '../../../utils/promise.js';
import type { IntegrationAuthenticationProviderDescriptor } from '../authentication/integrationAuthenticationProvider.js';
import type { IntegrationAuthenticationService } from '../authentication/integrationAuthenticationService.js';
import type {
	AuthenticationSessionLike as AuthenticationSession,
	ProviderAuthenticationSession,
} from '../authentication/models.js';
import { toTokenWithInfo } from '../authentication/models.js';
import { GitSelfManagedHostIntegrationId } from '../constants.js';
import type { IntegrationServiceContext } from '../context.js';
import type { IntegrationConnectionChangeEvent } from '../integrationService.js';
import type { SearchMyPullRequestsOptions } from '../models/gitHostIntegration.js';
import { GitHostIntegration } from '../models/gitHostIntegration.js';
import type { IntegrationKey } from '../models/integration.js';
import type { BitbucketRepositoryDescriptor } from './bitbucket/models.js';
import type { ProviderPullRequest, ProviderRepository } from './models.js';
import {
	fromProviderPullRequest,
	providerPullRequestMatchesSearch,
	ProviderPullRequestReviewState,
	providersMetadata,
	PullRequestFilter,
	toProviderPullRequestStates,
} from './models.js';
import type { ProvidersApi } from './providersApi.js';
import {
	collectProviderPagedResult,
	flatSettledOrThrow,
	parsePageCursor,
	toPageCursor,
} from './utils/providerPaging.js';

const metadata = providersMetadata[GitSelfManagedHostIntegrationId.BitbucketServer];
const authProvider = Object.freeze({ id: metadata.id, scopes: metadata.scopes });

export class BitbucketServerIntegration extends GitHostIntegration<
	GitSelfManagedHostIntegrationId.BitbucketServer,
	BitbucketRepositoryDescriptor
> {
	readonly authProvider: IntegrationAuthenticationProviderDescriptor = authProvider;
	readonly id = GitSelfManagedHostIntegrationId.BitbucketServer;
	protected readonly key =
		`${this.id}:${this.domain}` satisfies IntegrationKey<GitSelfManagedHostIntegrationId.BitbucketServer>;
	readonly name: string = 'Bitbucket Data Center';

	constructor(
		ctx: IntegrationServiceContext,
		authenticationService: IntegrationAuthenticationService,
		getProvidersApi: () => Promise<ProvidersApi>,
		didChangeConnection: Emitter<IntegrationConnectionChangeEvent>,
		private readonly _domain: string,
	) {
		super(ctx, authenticationService, getProvidersApi, didChangeConnection);
	}

	get domain(): string {
		return this._domain;
	}

	protected get apiBaseUrl(): string {
		const protocol = this._session?.protocol ?? 'https:';
		return `${protocol}//${this.domain}/rest/api/1.0`;
	}

	protected override async mergeProviderPullRequest(
		session: ProviderAuthenticationSession,
		pr: PullRequest,
		options?: {
			mergeMethod?: PullRequestMergeMethod;
		},
	): Promise<boolean> {
		const api = await this.getProvidersApi();
		return api.mergePullRequest(toTokenWithInfo(this.id, session), pr, {
			mergeMethod: options?.mergeMethod,
			baseUrl: this.apiBaseUrl,
		});
	}

	protected override async getProviderAccountForCommit(
		session: ProviderAuthenticationSession,
		repo: BitbucketRepositoryDescriptor,
		rev: string,
		options?: {
			avatarSize?: number;
		},
	): Promise<Account | UnidentifiedAuthor | undefined> {
		return (await this.authenticationService.apis.bitbucket)?.getServerAccountForCommit(
			this,
			toTokenWithInfo(this.id, session),
			repo.owner,
			repo.name,
			rev,
			this.apiBaseUrl,
			{
				avatarSize: options?.avatarSize,
			},
		);
	}

	protected override async getProviderAccountForEmail(
		_session: AuthenticationSession,
		_repo: BitbucketRepositoryDescriptor,
		_email: string,
		_options?: {
			avatarSize?: number;
		},
	): Promise<Account | undefined> {
		return Promise.resolve(undefined);
	}

	protected override async getProviderDefaultBranch(
		_session: AuthenticationSession,
		_repo: BitbucketRepositoryDescriptor,
	): Promise<DefaultBranch | undefined> {
		return Promise.resolve(undefined);
	}

	protected override async getProviderLinkedIssueOrPullRequest(
		session: ProviderAuthenticationSession,
		repo: BitbucketRepositoryDescriptor,
		{ id }: { id: string; key: string },
		type: undefined | IssueOrPullRequestType,
	): Promise<IssueOrPullRequest | undefined> {
		if (type === 'issue') {
			return undefined;
		}
		return (await this.authenticationService.apis.bitbucket)?.getServerPullRequestById(
			this,
			toTokenWithInfo(this.id, session),
			repo.owner,
			repo.name,
			id,
			this.apiBaseUrl,
		);
	}

	protected override async getProviderIssue(
		_session: AuthenticationSession,
		_repo: BitbucketRepositoryDescriptor,
		_id: string,
	): Promise<Issue | undefined> {
		return Promise.resolve(undefined);
	}

	protected override async getProviderPullRequestForBranch(
		session: ProviderAuthenticationSession,
		repo: BitbucketRepositoryDescriptor,
		branch: string,
		_options?: {
			avatarSize?: number;
			include?: PullRequestState[];
		},
	): Promise<PullRequest | undefined> {
		return (await this.authenticationService.apis.bitbucket)?.getServerPullRequestForBranch(
			this,
			toTokenWithInfo(this.id, session),
			repo.owner,
			repo.name,
			branch,
			this.apiBaseUrl,
		);
	}

	protected override async getProviderPullRequestForCommit(
		session: ProviderAuthenticationSession,
		repo: BitbucketRepositoryDescriptor,
		rev: string,
	): Promise<PullRequest | undefined> {
		return (await this.authenticationService.apis.bitbucket)?.getServerPullRequestForCommit(
			this,
			toTokenWithInfo(this.id, session),
			repo.owner,
			repo.name,
			rev,
			this.apiBaseUrl,
		);
	}

	public override async getRepoInfo(repo: {
		owner: string;
		name: string;
		project?: string;
		connectionId?: string;
	}): Promise<ProviderRepository | undefined> {
		const api = await this.getProvidersApi();
		// `connectionId` targets a specific account (multi-account); omitted reads the primary.
		const session = await this.resolveReadSession(repo.connectionId, undefined);
		if (session == null) return undefined;

		return api.getRepo(toTokenWithInfo(this.id, session), repo.owner, repo.name, repo.project, {
			baseUrl: this.apiBaseUrl,
		});
	}

	protected override async getProviderRepositoryMetadata(
		_session: AuthenticationSession,
		_repo: BitbucketRepositoryDescriptor,
		_cancellation?: AbortSignal,
	): Promise<RepositoryMetadata | undefined> {
		return Promise.resolve(undefined);
	}

	private _accounts: Map<string, Account | undefined> | undefined;
	protected override async getProviderCurrentAccount(
		session: ProviderAuthenticationSession,
	): Promise<Account | undefined> {
		const { accessToken } = session;
		this._accounts ??= new Map<string, Account | undefined>();

		const cachedAccount = this._accounts.get(accessToken);
		if (cachedAccount == null) {
			const api = await this.getProvidersApi();
			const user = await api.getCurrentUser(toTokenWithInfo(this.id, session), {
				baseUrl: this.apiBaseUrl,
			});
			this._accounts.set(
				accessToken,
				user
					? {
							provider: this,
							id: user.id,
							name: user.name ?? undefined,
							email: user.email ?? undefined,
							avatarUrl: user.avatarUrl ?? undefined,
							username: user.username ?? undefined,
						}
					: undefined,
			);
		}

		return this._accounts.get(accessToken);
	}

	protected override async searchProviderMyPullRequests(
		session: ProviderAuthenticationSession,
		repos?: BitbucketRepositoryDescriptor[],
		_cancellation?: AbortSignal,
		_silent?: boolean,
		state?: PullRequestStateFilter,
		_options?: SearchMyPullRequestsOptions,
	): Promise<PullRequest[] | undefined> {
		if (repos != null) {
			// TODO: implement repos version
			return undefined;
		}

		const api = await this.getProvidersApi();
		if (!api) {
			return undefined;
		}

		const prs = await api.getBitbucketServerPullRequestsForCurrentUser(
			toTokenWithInfo(this.id, session),
			this.apiBaseUrl,
			{ states: toProviderPullRequestStates(state) },
		);
		return prs?.data.map(pr => fromProviderPullRequest(pr, this));
	}

	protected override async getProviderMyPullRequestsForUser(
		session: ProviderAuthenticationSession,
		options?: { state?: PullRequestStateFilter[]; cursor?: string; filters?: PullRequestFilter[] },
	): Promise<PagedResult<ProviderPullRequest> | undefined> {
		const api = await this.getProvidersApi();
		const states = toProviderPullRequestStates(options?.state);
		// provider-apis translates the public 1-based `page` to Bitbucket Server's `start` offset and normalizes
		// `nextPageStart` back to the next page number. Thread that number inside our opaque cursor so the
		// ProviderBackend sweep drives the drain (bounded by its maxPages).
		const page = parsePageCursor(options?.cursor);
		const result = await api.getBitbucketServerPullRequestsForCurrentUser(
			toTokenWithInfo(this.id, session),
			this.apiBaseUrl,
			{ states: states, page: page },
		);
		if (result == null) return undefined;

		const account = options?.filters?.length ? await this.getProviderCurrentAccount(session) : undefined;
		const identifiers = new Set([account?.id, account?.username].filter((id): id is string => id != null));
		if (options?.filters?.length && identifiers.size === 0) {
			throw new Error(
				'Unable to resolve the current Bitbucket Data Center account for the requested pull request filters.',
			);
		}

		const values = options?.filters?.length
			? result.data.filter(pr => {
					const isCurrentUser = (user: { id?: string | null; username?: string | null } | null | undefined) =>
						user != null &&
						((user.id != null && identifiers.has(user.id)) ||
							(user.username != null && identifiers.has(user.username)));
					const isAuthor = isCurrentUser(pr.author);
					const isRequestedReviewer = pr.reviews?.some(
						review =>
							isCurrentUser(review.reviewer) &&
							review.state === ProviderPullRequestReviewState.ReviewRequested,
					);
					return (
						(options.filters!.includes(PullRequestFilter.Author) && isAuthor) ||
						(options.filters!.includes(PullRequestFilter.ReviewRequested) && isRequestedReviewer)
					);
				})
			: result.data;

		return {
			values: values,
			paging: {
				more: result.hasMore,
				cursor: result.hasMore && result.nextPage != null ? toPageCursor(result.nextPage) : '{}',
			},
		};
	}

	protected override async searchProviderPullRequests(
		session: ProviderAuthenticationSession,
		searchQuery: string,
		repos?: BitbucketRepositoryDescriptor[],
		cancellation?: AbortSignal,
		options?: { include?: PullRequestState[] },
	): Promise<PullRequest[] | undefined> {
		if (cancellation?.aborted) throw new CancellationError();

		const api = await this.getProvidersApi();
		if (!api) return undefined;

		const repoInputs =
			repos != null
				? repos.map(r => ({ name: r.name, namespace: r.owner }))
				: await this.getWorkspaceRepoInputs();
		if (cancellation?.aborted) throw new CancellationError();
		// An explicitly-empty `repos` means "search these zero repos" -> no results; reserve `undefined`
		// ("scope couldn't be determined") for when no repos were requested and none were discovered.
		if (repoInputs.length === 0) return repos != null ? [] : undefined;

		const token = toTokenWithInfo(this.id, session);
		const states = toProviderPullRequestStates(options?.include);
		const providerPullRequests = await flatSettledOrThrow(
			repoInputs.map(async repo => {
				const result = await collectProviderPagedResult(cursor => {
					if (cancellation?.aborted) throw new CancellationError();

					return api.getPullRequestsForRepo(token, repo, {
						baseUrl: this.apiBaseUrl,
						cursor: cursor,
						states: states,
					});
				});
				return result.values;
			}),
		);
		if (cancellation?.aborted) throw new CancellationError();

		return providerPullRequests
			.filter(pr => providerPullRequestMatchesSearch(pr, searchQuery))
			.map(pr => fromProviderPullRequest(pr, this));
	}

	private async getWorkspaceRepoInputs(): Promise<{ name: string; namespace: string }[]> {
		const remotes = await this.ctx.repositories.getOpenRemotes();
		const inputs = await nonnullSettled(
			remotes.map(async (r: GitRemote) => {
				const integration = await this.authenticationService.getByRemote(r);
				if (integration !== this) return undefined;

				// Use the remote provider's parsing so the Bitbucket Server `scm/<project>/<repo>` prefix is
				// stripped; a raw `path.split('/')` would yield namespace=`scm`, name=`<project>`.
				const namespace = r.provider?.owner;
				const name = r.provider?.repoName;
				return namespace != null && name != null ? { name: name, namespace: namespace } : undefined;
			}),
		);
		// Dedupe: a repo with multiple remotes (e.g. `origin` + `upstream`) can map to the same input,
		// which would otherwise fetch and return the same PRs more than once.
		return [...new Map(inputs.map(i => [`${i.namespace}/${i.name}`, i])).values()];
	}

	protected override async searchProviderMyIssues(
		_session: AuthenticationSession,
		_repos?: BitbucketRepositoryDescriptor[],
	): Promise<IssueShape[] | undefined> {
		return Promise.resolve(undefined);
	}

	/**
	 * Bitbucket Data Center exposes no issue tracker at all (issues live in Jira), so — like Bitbucket Cloud,
	 * whose own tracker is deprecated — it is not an issue provider on the ProviderBackend surface. Without this
	 * the facade would take `supportsIssues`' default `true` and route the read to a provider that registers no
	 * issue client: the repo-scoped path fails with the SDK's `does not support function: getIssuesForReposFn`
	 * as an opaque `kind: 'other'` warning, and `broadenIssues` first drains every repo of the org before hitting
	 * the same failure. Its metadata already declares no issue filters, so this keeps both halves of the
	 * capability answer consistent.
	 */
	override get supportsIssues(): boolean {
		return false;
	}

	private readonly storagePrefix = 'bitbucket-server';
	protected override async providerOnConnect(): Promise<void> {
		if (this._session == null) return;

		const accountStorageKey = md5(this._session.accessToken);

		const storedAccount = this.ctx.storage.get(`${this.storagePrefix}:${accountStorageKey}:account`);

		let account: Account | undefined = storedAccount?.data ? { ...storedAccount.data, provider: this } : undefined;

		if (storedAccount == null) {
			account = await this.getProviderCurrentAccount(this._session);
			if (account != null) {
				// Clear all other stored workspaces and repositories and accounts when our session changes
				await this.ctx.storage.deleteWithPrefix(this.storagePrefix);
				await this.ctx.storage.store(`${this.storagePrefix}:${accountStorageKey}:account`, {
					v: 1,
					timestamp: Date.now(),
					data: {
						id: account.id,
						name: account.name,
						email: account.email,
						avatarUrl: account.avatarUrl,
						username: account.username,
					},
				});
			}
		}
		this._accounts ??= new Map<string, Account | undefined>();
		this._accounts.set(this._session.accessToken, account);
	}

	protected override providerOnDisconnect(): void {
		this._accounts = undefined;
	}
}
