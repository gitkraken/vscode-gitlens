import { getGitHubPullRequestIdentityFromMaybeUrl as _getGitHubPullRequestIdentityFromMaybeUrl } from '../../../git-github/api/github.utils.js';
import type { PullRequestUrlIdentity } from '../../../../git/utils/pullRequest.utils.js';
import type { GitCloudHostIntegrationId, GitSelfManagedHostIntegrationId } from '../../constants.js';

export type GitHubIntegrationIds =
	| GitCloudHostIntegrationId.GitHub
	| GitSelfManagedHostIntegrationId.CloudGitHubEnterprise;

export { isMaybeGitHubPullRequestUrl } from '../../../git-github/api/github.utils.js';

export function getGitHubPullRequestIdentityFromMaybeUrl(
	search: string,
): (PullRequestUrlIdentity & { provider: undefined }) | undefined;
export function getGitHubPullRequestIdentityFromMaybeUrl(
	search: string,
	id: GitHubIntegrationIds,
): (PullRequestUrlIdentity & { provider: GitHubIntegrationIds }) | undefined;
export function getGitHubPullRequestIdentityFromMaybeUrl(
	search: string,
	id?: GitHubIntegrationIds,
): (PullRequestUrlIdentity & { provider: GitHubIntegrationIds | undefined }) | undefined {
	return _getGitHubPullRequestIdentityFromMaybeUrl(search, id as any);
}
