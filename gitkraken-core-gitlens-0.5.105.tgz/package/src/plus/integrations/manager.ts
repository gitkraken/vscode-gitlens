import type { IssueSearchCriteria, IssueShape } from '../../git/models/issue.js';
import type { PullRequestShape, PullRequestStateFilter } from '../../git/models/pullRequest.js';
import type { Event } from '../../utils/event.js';
import type { ConfiguredIntegrationsChangeEvent } from './authentication/configuredIntegrationService.js';
import type { ConfiguredIntegrationDescriptor } from './authentication/models.js';
import type { IntegrationIds } from './constants.js';
import type { IssueFilter, IssueSearchCapabilities, PullRequestFilter } from './providerFilters.js';
import type { IssueCountResult, IssueCountScope } from './reads/counts.js';
import type {
	ConnectionStateChangeEvent,
	ProviderBroadenResult,
	ProviderOrganization,
	ProviderPagedResult,
	ProviderRepositoryShape,
	ProviderResult,
	ProviderSweepResult,
	ResolveRepositoryResult,
} from './results.js';

/** Neutral repository input accepted by repo-scoped provider reads. */
export interface ProviderRepositoryInput {
	namespace: string;
	name: string;
	project?: string;
	id?: string;
}

export type ProviderRepositoriesInput = (string | number)[] | ProviderRepositoryInput[];

/**
 * One provider slice in a pull-request sweep.
 *
 * A sweep accepts at most one target per provider because its failure attribution is provider-scoped.
 * `domain` is a fallback for self-managed hosts whose authentication provider doesn't persist a configured
 * connection; a configured `connectionId` domain takes precedence when both are supplied. It must come from
 * the trusted authentication configuration, not repository or remote data.
 */
export interface ProviderSweepTarget {
	providerId: IntegrationIds;
	connectionId?: string;
	domain?: string;
	/**
	 * Relationship filters for this provider slice. With sweep-level `repos`, members are provider query
	 * constraints; without `repos`, they form an exact OR union. The whole set is validated against the
	 * selected path's capabilities.
	 *
	 * This per-target form lets a cross-provider sweep preserve provider-specific semantics without leaking
	 * provider query details into the consumer. It overrides the sweep-level `filters` for this target.
	 */
	filters?: PullRequestFilter[];
}

type ProviderSweepSelection =
	| {
			targets: readonly ProviderSweepTarget[];
			providerIds?: never;
			connectionId?: never;
	  }
	| {
			targets?: never;
			providerIds?: IntegrationIds[];
			/**
			 * Legacy single-provider selector. It is ignored when `providerIds` contains more than one provider;
			 * use `targets` to select connections independently in a multi-provider sweep.
			 */
			connectionId?: string;
	  };

/**
 * One org slice in an issue-broadening fan-out. `domain` is a fallback for self-managed hosts whose
 * authentication provider doesn't persist a configured connection; a configured `connectionId` domain takes
 * precedence when both are supplied. It must come from the trusted authentication configuration, not
 * repository or remote data.
 */
export interface ProviderBroadenOrg {
	providerId: IntegrationIds;
	name: string;
	connectionId?: string;
	domain?: string;
}

type PullRequestSweepCommonOptions = {
	repos?: ProviderRepositoriesInput;
	/** Named `states` to match {@link IntegrationManager.listPullRequestsPage}; a mismatch here read as silently ignored. */
	states?: PullRequestStateFilter[];
	/**
	 * Relationship filters applied to every target. Repo-scoped reads combine them as provider query
	 * constraints (normally an intersection); account-wide reads form an exact OR union. The set is validated
	 * against `pullRequests` or `pullRequestsAccountWide`, respectively. A target's own `filters` overrides this.
	 */
	filters?: PullRequestFilter[];
	/**
	 * Account-wide only: include review-requested PRs when the provider's native "my PRs" query omits them.
	 * This extends the provider-native result; it is not a narrowing filter.
	 */
	includeReviewRequested?: boolean;
	/**
	 * Account-wide only: fetch the full PR projection (review decision, review requests, latest reviews)
	 * instead of the default summary/lite one. Opt-in because it enlarges every account-wide page; callers
	 * that classify by review state (e.g. a "needs my review" surface) set it, others keep the lean read.
	 */
	includeReviews?: boolean;
	forceSync?: boolean;
	maxPages?: number;
};

export type PullRequestSweepOptions = PullRequestSweepCommonOptions & ProviderSweepSelection;

export type ClosedPullRequestSweepOptions = Omit<PullRequestSweepCommonOptions, 'states'> & ProviderSweepSelection;

/**
 * Organization discovery either fans out without a provider-specific target, or pins every scoped selector
 * to one provider. A `connectionId`/`domain` without `providerId` is ambiguous and therefore unrepresentable.
 */
export type ListOrgsOptions =
	| {
			providerId: IntegrationIds;
			connectionId?: string;
			domain?: string;
	  }
	| {
			providerId?: never;
			connectionId?: never;
			domain?: never;
	  };

/**
 * Project discovery follows the same provider-targeting rule as {@link ListOrgsOptions}; `org` may still
 * narrow either a single-provider read or the unscoped fan-out.
 */
export type ListProjectsOptions =
	| {
			providerId: IntegrationIds;
			org?: string;
			connectionId?: string;
			domain?: string;
	  }
	| {
			providerId?: never;
			org?: string;
			connectionId?: never;
			domain?: never;
	  };

/**
 * Public, provider-neutral integration facade. Provider clients and integration model instances remain private
 * implementation details so SDK changes don't expand this contract.
 *
 * ## Paging contract
 *
 * Every paged read (`listRepos`, `listPullRequestsPage`, `listIssuesPage`, `listIssueTrackerIssuesPage`,
 * `broadenIssues`) takes both `page` and `cursor`, and the two are NOT interchangeable:
 *
 * - **Supplying `cursor` guarantees a single upstream round trip per provider scope.** A threaded continuation
 *   is handed to the provider as-is; the facade never walks the pages before it. This is a guarantee, not an
 *   optimization: a consumer that threads `cursor` back pays O(1) requests per page.
 * - **Supplying only `page` (> 1) may cost O(page) upstream requests.** Cursor-backed reads such as GitHub
 *   searches and broaden fan-outs can't be addressed by number, so the facade drains the pages before the
 *   requested one internally and returns just page N. Providers whose account-wide reads aggregate into one
 *   terminal page do not incur that drain. The fallback for cursor-backed reads MUST be kept: it supports the
 *   first page-number-only read after a refresh, where no cursor was persisted.
 * - Prefer `cursor` when both are available. Pass `page` alongside it so the result's positional
 *   `page.currentPage` reflects where the caller is (the convention is documented on `ProviderPageInfo`); the
 *   cursor, not the page number, is what actually advances the read.
 * - `hasMore` is only ever true with a `cursor` the caller can act on. A provider that reports another page
 *   but hands back no usable continuation is reported as terminal-but-incomplete (`hasMore: false` +
 *   `page.truncated`), never as a page that can't be requested.
 */
export interface IntegrationManager {
	readonly onDidChange: Event<ConfiguredIntegrationsChangeEvent>;
	readonly onDidChangeConnectionState: Event<ConnectionStateChangeEvent>;

	dispose(): void;

	getConfigured(
		id?: IntegrationIds,
		options?: { cloud?: boolean; domain?: string },
	): ConfiguredIntegrationDescriptor[];
	/**
	 * The `filters` a provider accepts on `listPullRequestsPage`/`listIssuesPage` and the sweeps.
	 *
	 * The filter contract is all-or-nothing: a set containing even one unsupported filter is refused (empty
	 * `items` + a warning + `fetchFailed`) rather than narrowed, because falling through to an unfiltered read
	 * would return every pull request instead of the user's. Intersect against this before the read so a
	 * cross-provider filter set never turns into a failed page. Static per provider — no connection required.
	 *
	 * Empty means no filter of that kind is expressible (issue trackers have no pull requests; Bitbucket exposes
	 * no issues), which means "pass no filters", not "error".
	 *
	 * `pullRequests` covers repo-scoped PR reads; `pullRequestsAccountWide` covers account-wide PR reads.
	 * `issues` covers the repo-scoped issue read; `issuesAccountWide` covers the account-wide one (no `repos`).
	 * They differ because they are different provider queries — GitLab can express `Assignee` and `Author`
	 * account-wide, but not `Mention` — and `listIssuesPage` validates against whichever the read uses.
	 *
	 * An ISSUE TRACKER (Jira/Linear/Trello) reports its filters under `issues`, and
	 * {@link IntegrationManager.listIssueTrackerIssuesPage} validates against that field. Its
	 * `issuesAccountWide` is empty — those two fields split the git-host reads, and a tracker has neither of
	 * them (its issues live under resource → project) — so intersecting a tracker's filters against
	 * `issuesAccountWide` would read "cannot filter" for a provider that filters fine.
	 *
	 * This is a capability table, not a recommendation: a consumer matching another tool's behavior may pass fewer
	 * filters than are listed, or none where the underlying read is already scoped.
	 */
	getSupportedFilters(providerId: IntegrationIds): {
		pullRequests: PullRequestFilter[];
		/** Optional for structural compatibility; missing means no account-wide narrowing filters are supported. */
		pullRequestsAccountWide?: PullRequestFilter[];
		issues: IssueFilter[];
		issuesAccountWide: IssueFilter[];
		/**
		 * What {@link searchIssuesPage} (and {@link countIssues}, over the same criteria) can express for this
		 * provider. Always present: a provider with no filtered issue search reports an empty `relationships` and
		 * all-false flags, which is the signal to hide that surface rather than to hide individual chips.
		 */
		issueSearch: IssueSearchCapabilities;
	};
	/** Forces an authoritative cloud connection refresh. Rejects if the backend connection list cannot be read. */
	refreshConnections(): Promise<void>;
	/** Rejects unless `connectionId` is a configured cloud connection for `id`. */
	setPrimaryConnection(id: IntegrationIds, connectionId: string): Promise<void>;
	/** Rejects unless `connectionId` is a configured cloud connection for `id`. */
	deleteConnection(id: IntegrationIds, connectionId: string): Promise<void>;

	listOrgs(options?: ListOrgsOptions): Promise<ProviderResult<ProviderOrganization>>;
	listProjects(options?: ListProjectsOptions): Promise<ProviderResult<ProviderOrganization>>;
	listRepos(options: {
		providerId: IntegrationIds;
		org?: string;
		project?: string;
		/**
		 * Requested 1-based page. Cursor-only providers are advanced internally when no `cursor` is supplied,
		 * so a direct page-N request can cost O(page) upstream calls.
		 */
		page?: number;
		/** Continuation from a prior page's `cursor`; supplying it costs exactly one upstream request per scope. */
		cursor?: string;
		/**
		 * Requested page size. Advisory: the repos read core is cursor-only and takes no page size, so the
		 * provider's own size is what applies — `page.itemsPerPage` reports what was actually returned.
		 */
		itemsPerPage?: number;
		connectionId?: string;
		/** Self-managed host domain fallback; see {@link ProviderSweepTarget.domain}. */
		domain?: string;
	}): Promise<ProviderPagedResult<ProviderRepositoryShape>>;
	listPullRequestsPage(options: {
		providerId: IntegrationIds;
		repos?: ProviderRepositoriesInput;
		states?: PullRequestStateFilter[];
		/**
		 * Relationship filters. Repo-scoped reads combine members as provider query constraints (normally an
		 * intersection), so issue separate reads when the desired result is a union. Account-wide members form an
		 * exact OR union. Each path validates the whole set against its corresponding capability.
		 */
		filters?: PullRequestFilter[];
		/**
		 * Account-wide only: include review-requested PRs when the provider's native "my PRs" query omits them.
		 * This extends the provider-native result; it is not a narrowing filter.
		 */
		includeReviewRequested?: boolean;
		/**
		 * Requested 1-based page. Without a `cursor` this may cost O(page) upstream requests on a cursor-only
		 * read (repo-scoped GitHub/GHE and account-wide providers that return continuations), which the facade
		 * drains internally.
		 */
		page?: number;
		/** Continuation from a prior page's `cursor`; supplying it costs exactly one upstream request per scope. */
		cursor?: string;
		/**
		 * Requested page size, honored on the repo-scoped path. The provider-defined account-wide read (no
		 * `repos`) takes no page size, so it is ignored there — `page.itemsPerPage` reports what was actually
		 * returned rather than echoing the request.
		 */
		itemsPerPage?: number;
		forceSync?: boolean;
		connectionId?: string;
		/**
		 * Explicit self-managed host domain. Used only when the requested connection has no configured domain;
		 * it must come from the trusted authentication configuration, not repository or remote data.
		 */
		domain?: string;
	}): Promise<ProviderPagedResult<PullRequestShape>>;
	listIssuesPage(options: {
		providerId: IntegrationIds;
		repos?: ProviderRepositoriesInput;
		/**
		 * Narrows the account-wide read (no `repos`) to one org/account, and `project` to one project within it.
		 * Only a git host with a project tier (Azure DevOps) can scope this server-side; for any other provider
		 * either option is rejected with a warning + `fetchFailed` rather than silently returning an unscoped
		 * list. Ignored when `repos` is supplied, since those repos are already the scope.
		 */
		org?: string;
		project?: string;
		/**
		 * Narrows to the requested relationship(s), validated against `getSupportedFilters().issues` on the
		 * repo-scoped path and `.issuesAccountWide` on the account-wide one.
		 *
		 * On the account-wide path this REPLACES the provider's own definition of "my issues" — GitHub/GHE
		 * authored + assigned + mentioned, Azure assigned + authored, and GitLab assigned-to-me — so
		 * `[Assignee]` gets `assignee:@me` semantics wherever it's expressible. Narrowing must happen here rather
		 * than on the returned page: the excluded items still counted toward the provider's paging, so filtering
		 * afterward leaves `items` describing a different result set than `hasMore`/`cursor`.
		 *
		 * A set the provider can't express server-side is refused whole (warning + `fetchFailed`), never widened.
		 */
		filters?: IssueFilter[];
		/** Broadens to every assignee. On account-wide reads it contradicts `filters`, so passing both is refused. */
		includeAllAssignees?: boolean;
		/**
		 * Requested 1-based page. Without a `cursor` this may cost O(page) upstream requests on cursor-backed
		 * reads such as repo-scoped GitHub/GHE; aggregate single-page account-wide reads remain O(1).
		 */
		page?: number;
		/** Continuation from a prior page's `cursor`; supplying it costs exactly one upstream request per scope. */
		cursor?: string;
		itemsPerPage?: number;
		forceSync?: boolean;
		connectionId?: string;
		/** Self-managed host domain fallback; see {@link ProviderSweepTarget.domain}. */
		domain?: string;
	}): Promise<ProviderPagedResult<IssueShape>>;
	/**
	 * Issues matching structured criteria over a repository/org scope, with NO forced relationship to the current
	 * user — the issue counterpart of the PR search, and the read to use for "every issue in these repos matching
	 * X" rather than "my issues".
	 *
	 * Why this and not {@link listIssuesPage}: that read is either bound to the user's own relationships
	 * (account-wide) or routed through the SDK's repo-scoped read, whose over-limit recovery walk can spend up to
	 * 128 sequential requests and still return an incomplete set. This one is a single request per page.
	 *
	 * Three parts of the contract worth reading before calling:
	 *
	 * - **Scope is mandatory.** Pass `repos`, `org`, or a user relationship (`authored`/`assigned`/`mentioned`).
	 *   `any-assignee`/`unassigned` do NOT scope anything — either alone matches every such issue on the host —
	 *   so a call carrying only those is refused (warning + `fetchFailed`).
	 * - **Ordering is always most-recently-updated-first**, not an option. A "show the N most recent" policy at
	 *   the provider's result ceiling is only correct under a guaranteed order.
	 * - **At the result ceiling the read SUCCEEDS.** It reports an omission carrying `totalCount` (how many
	 *   matched) and `limit` (how many are reachable) with `recovery: 'none'`, so a consumer can say "19.240
	 *   matched, showing the 1.000 most recent" and know not to offer a "load more". It never falls back to a
	 *   per-repository recovery walk.
	 *
	 * Check `getSupportedFilters().issueSearch` first: a provider with no filtered issue search reports empty
	 * relationships (and this read refuses), and a criterion it can't express refuses the whole read rather than
	 * serving a wider result than asked for.
	 */
	searchIssuesPage(options: {
		providerId: IntegrationIds;
		/** Repositories to search. Combines with `org`; both constrain the same query. */
		repos?: ProviderRepositoriesInput;
		/** Organization/account to search. Combines with `repos`. */
		org?: string;
		criteria?: IssueSearchCriteria;
		/**
		 * Requested 1-based page. This read is cursor-only, so without a `cursor` reaching page N costs O(N)
		 * upstream requests; pass the previous page's cursor to make it exactly one.
		 */
		page?: number;
		cursor?: string;
		/**
		 * Page size PER RELATIONSHIP, not per page. Each requested relationship is its own provider query, so a
		 * page of a 2-relationship search returns up to `2 × itemsPerPage` items before deduplication — and fewer
		 * than that when the two overlap. `page.itemsPerPage` reports what actually came back, so size the UI off
		 * that rather than off this. A provider may also cap it below what is asked for.
		 */
		itemsPerPage?: number;
		forceSync?: boolean;
		connectionId?: string;
		/** Self-managed host domain fallback; see {@link ProviderSweepTarget.domain}. */
		domain?: string;
	}): Promise<ProviderPagedResult<IssueShape>>;
	/**
	 * How many issues MATCH each scope, without fetching any of them — the probe behind a "this will fetch ~N
	 * issues" preview, and behind a live count next to a filter the user hasn't applied yet.
	 *
	 * Cheap by design: every scope that can share a request does, and no issue data crosses the wire (measured
	 * against GitHub, 30 counts are a single rate-limit point). Still a network request per batch, so debounce and
	 * cache it if it's driven from UI state.
	 *
	 * A separate method rather than a flag on {@link searchIssuesPage} because transferring zero issues is the
	 * whole point: a `countOnly` read would hand back a paged result whose `items`/`cursor`/`hasMore` are all
	 * meaningless.
	 *
	 * Results are echoed under the caller's own `key`, so no positional matching is needed. Per-scope isolation is
	 * the rule: a scope refused for its own reasons, or a batch that failed upstream, warns and drops only its own
	 * scopes (with `fetchFailed` set) while every other count still comes back.
	 *
	 * `count: undefined` means the provider didn't report one — NOT zero, which is a real answer. Render the
	 * difference: showing an unknown count as 0 tells the user a filter matches nothing when it may match
	 * thousands. A provider that can't count at all (only GitHub/GHE can today) refuses the probe outright rather
	 * than returning fabricated numbers.
	 */
	countIssues(options: {
		providerId: IntegrationIds;
		/** Each needs its own scope, and each requested relationship its own entry — see {@link IssueCountScope}. */
		scopes: readonly IssueCountScope[];
		connectionId?: string;
		/** Self-managed host domain fallback; see {@link ProviderSweepTarget.domain}. */
		domain?: string;
	}): Promise<ProviderResult<IssueCountResult>>;
	/** Issue trackers are cloud-only, so this read takes no `domain`. */
	listIssueTrackerIssuesPage(options: {
		providerId: IntegrationIds;
		org?: string;
		project?: string;
		filters?: IssueFilter[];
		includeAllAssignees?: boolean;
		forceSync?: boolean;
		page?: number;
		/**
		 * Opaque continuation from a prior result. It can bundle the next untouched project window with failed
		 * discovery/project retries and already-emitted project identities, so it is not equivalent to `page`.
		 * Thread it back verbatim. A retry-only cursor can remain when `hasMore` is false; reusing that cursor is
		 * an explicit manual retry, while `hasMore` represents automatic forward progress only.
		 */
		cursor?: string;
		/**
		 * Page size in PROJECTS, not issues (default 20): these providers have no cross-project issue cursor, so
		 * a page is a window of projects, each drained in full. Supplying it (or `page`/`cursor`) opts into
		 * pagination; omitting all three aggregates every matched project in one page.
		 */
		itemsPerPage?: number;
		connectionId?: string;
	}): Promise<ProviderPagedResult<IssueShape>>;
	sweepPullRequests(options?: PullRequestSweepOptions): Promise<ProviderSweepResult<PullRequestShape>>;
	sweepClosedPullRequests(options?: ClosedPullRequestSweepOptions): Promise<ProviderSweepResult<PullRequestShape>>;
	broadenIssues(options: {
		orgs: ProviderBroadenOrg[];
		/**
		 * Requested 1-based page. Without a `cursor` the fan-out is re-run once per prior page (O(page) rounds),
		 * since a per-org cursor bundle is the only way to address a later page.
		 */
		page?: number;
		/** Continuation from a prior page's `cursor`; supplying it runs exactly one fan-out round. */
		cursor?: string;
		forceSync?: boolean;
	}): Promise<ProviderBroadenResult<IssueShape>>;
	resolveRepository(options: {
		providerId?: IntegrationIds;
		remoteUrl: string;
		host?: string;
		connectionId?: string;
		/**
		 * Explicit self-managed host domain used to select the integration instance. It must come from trusted
		 * authentication configuration. Without it, the host parsed from `remoteUrl` is only a resolution
		 * candidate: the facade proceeds only when that host matches a configured integration, so repository
		 * data cannot select credentials for an arbitrary host.
		 */
		domain?: string;
	}): Promise<ResolveRepositoryResult>;
}
